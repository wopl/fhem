This driver is required for Windows XP/Vista/7.
Windows 8 does NOT require this driver because it can autodetect it correctly.
